This is a prototype font and is not the final version. I don't have much time for this, but I wanted to put something together at least for now. This is the font that is used on the Omniglot page. If you have any suggestions, I would appreciate hearing from you.

The use of the font is not simple:

1. The default is to use the small letters.
2. Capitalize the end of each word.
3. When the end of the word is a single, double, or triple vowel, capitalize the consonant preceeding it.
4. When two vowels are contiguous, capitalize the first vowel. (The capitalized vowel puts a space after the letter.)
5. When three or more vowels are contiguous, capitalize all but the last vowel.


Good luck!

Bob Weiland
bob@bobweiland.com
