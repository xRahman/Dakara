##################################################
MOHON DIBACA DULU SEBELUM MENGGUNAKAN FONT INI!!!
##################################################

Terima kasih telah mendownload font saya. Dengan mengunduh font ini, Anda setuju untuk menggunakannya hanya untuk proyek pribadi saja dan bukan untuk komersial atau apa pun di mana Anda mencari penghasilan dengan font ini.


Jika Anda memerlukan Lisensi tambahan, silakan hubungi saya melalui email:
nryntdw@gmail.com

Berapapun donasi yang anda berikan, adalah sebuah penghargaan untuk kami :)
jika ingin berdonasi, ini link paypal saya:
https://paypal.me/nuryantodwi


Terima kasih atas penghargaan Anda!

===========================================================

This demo font is for PERSONAL USE ONLY! But any donation is very appreciated
Paypal account for donation: https://paypal.me/nuryantodwi

For use of commercial licenses and full versions please contact me via email contact
nryntdw@gmail.com

Visit my store
https://www.creativefabrica.com/designer/nryntdw/ref/377367/
instagram @imaginatype

Thank you!