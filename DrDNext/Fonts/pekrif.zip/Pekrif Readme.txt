Thank you for downloading the P�krif Normal font. To use it effectively, you should be familiar with the character mappings. Since the P�krif contains almost twice as many letters as the Roman alphabet, and since the P�krif does not have letters of different cases, most letter keys have two different P�krif letters mapped onto each of them; the only exception to this is P, which has mappings for the P�krif p and its initial end element. Below is a complete list of mappings, given with the P�krif's transliteration (superscript letters have been indicated with parentheses):

Upper-case
Q W E R T Y U I O P
� w � r t y � ai � p
A S D F G H J K L
ei s d f g h j k l
Z X C V B N M
z � ch v b n m

Lower-case
q w e r t y u i o p
ue � � [ak] th (y) u i o [p�kh initial element]
a s d f g h j k l
a sh (n) r' (e) hw e kh y�
z x c v b n m
zh oe oi dh ou ng yu

Numbers for 0 through 9 have been mapped onto the standard number keys. While holding shift down, you can type the following symbols:
~  1 2  3 4  5 6 7 8 9 0
10 ! 11 ordinal 12 % raise-to-power [p�kh final element] end-fraction ( )

Basic mathematical operators have been mapped to their standard codespots, as have all inequality symbols except for the less-than and greater-than symbols. These have respectively been mapped to capital and lower-case thorn (alt-0222 and alt-0254). Pi is also mapped to its normal codespot at Unicode 03C0. Imaginary number i, however, is mapped to lower-case i-acute, codespot alt-0237.

The end elements for p (p�kh) have already been listed; the other end elements' codespots are as follows:
Lower-case
` end element for �, �, ak, e, �, y, g, m, and ng
[ initial element for sh and final element for s
] final element for sh and initial element for s
\ end element for ou and oi
/ initial element for ai and kh
Upper-case
{ initial element for ei, oe, ue, o, t, and b; final element for �, �, hw, and dh
} final element for ei, oe, ue, o, t, and b; initial element for �, �, hw, and dh
| final element for ai and kh
< initial element for �, �, u, and yu; final element for y�
> final element for �, �, u, and yu; initial element for y�
Alt-codes only on American keyboards
Left guillemot, alt-0171: initial element for r' and z; final element for v; end element for h and f
Right guilemot, alt-0187: final element for r' and z; initial element for v
�, alt-0224: end element for a and r
�, alt-0225: initial element for i and k
�, alt-0226: final element for i and k
�, alt-0227: initial element for th
�, alt-0228: final element for th
�, alt-0232: initial element for zh
�, alt-0233: final element for zh
�, alt-0234: initial element for l
�, alt-0235: final element for l

Concerning punctuation, the period/full stop, comma, question mark, exclamation point, semicolon, colon, quotation marks, parentheses and ellipsis are all mapped to their normal codespots. The hyphen is mapped to the underscore. The interrobang is mapped to the inverted exclamation mark at alt-0161, while the uncertainty mark is mapped to the inverted question mark at alt-0191. The stress mark is mapped to the broken bar at alt-0166; to make it look right, it should be typed after the vowel it modifies.

LEGAL NOTICE
P�krif Normal � 2005, 2006 Zack Hart. All rights reserved.
Do not claim this font as your own work (plagiarism), as you will face severe legal consequences. You are, however, permitted to distribute this font and readme as a unit to whomever you wish without further limitation.